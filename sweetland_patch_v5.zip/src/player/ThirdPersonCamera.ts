import * as THREE from "three";
import { clamp } from "../core/clamp";

export class ThirdPersonCamera {
  // Yaw/pitch controlled by mouse (pointer lock)
  yaw = 0;
  pitch = -0.55; // angled down
  // A bit farther out for better platforming visibility
  distance = 8.2;
  height = 3.0;

  // Smoothed camera position
  private camPos = new THREE.Vector3();
  private targetPos = new THREE.Vector3();

  constructor(private camera: THREE.PerspectiveCamera) {}

  updateFromMouse(dx: number, dy: number): void {
    const sens = 0.0024;
    this.yaw -= dx * sens;
    this.pitch -= dy * sens;
    this.pitch = clamp(this.pitch, -1.25, -0.15);
  }

  update(targetWorldPos: THREE.Vector3, dt: number): void {
    // Camera target is slightly above player
    this.targetPos.copy(targetWorldPos).add(new THREE.Vector3(0, 1.2, 0));

    // Spherical offsets
    const x = Math.sin(this.yaw) * Math.cos(this.pitch) * this.distance;
    const y = Math.sin(this.pitch) * this.distance + this.height;
    const z = Math.cos(this.yaw) * Math.cos(this.pitch) * this.distance;

    const desired = this.targetPos.clone().add(new THREE.Vector3(x, y, z));

    // Smooth follow (critically damp-ish)
    const k = 1 - Math.pow(0.001, dt);
    this.camPos.lerp(desired, k);

    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.targetPos);
  }
}
